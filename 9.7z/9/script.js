function calculate() {
    let a = Number(document.getElementById("num1").value);
    let b = Number(document.getElementById("num2").value);

    let sum = a + b;

    document.getElementById("result").textContent = sum;
}

function calcPrice() {
    let price = Number(document.getElementById("product").value);
    let qty = Number(document.getElementById("qty").value);

    if (price === 0) {
        alert("Будь ласка, оберіть товар");
        return;
    }

    let total = price * qty;
    document.getElementById("total").textContent = total;
}

function checkLogin() {
    let login = document.getElementById("login").value;
    let password = document.getElementById("password").value;
    let message = document.getElementById("message");

    if (login === "admin" && password === "1234") {
        message.style.color = "green";
        message.textContent = "Вхід успішний!";
    } else {
        message.style.color = "red";
        message.textContent = "Неправильний логін або пароль";
    }
}