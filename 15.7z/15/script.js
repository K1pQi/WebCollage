document.addEventListener('DOMContentLoaded', function() {
    const starsContainer = document.querySelector('.stars');
    const addStarBtn = document.getElementById('addStarBtn');
    const addMeteorBtn = document.getElementById('addMeteorBtn');
    const toggleModeBtn = document.getElementById('toggleModeBtn');
    const resetBtn = document.getElementById('resetBtn');
    const starCount = document.getElementById('starCount');
    const createdStars = document.getElementById('createdStars');
    const modeStatus = document.getElementById('modeStatus');
    const constellationItems = document.querySelectorAll('.const-item');
    
    let totalStars = 0;
    let createdCount = 0;
    
    function createStar() {
        const star = document.createElement('div');
        star.className = 'star';
        
        const size = Math.random() * 3 + 1;
        star.style.width = size + 'px';
        star.style.height = size + 'px';
        star.style.left = Math.random() * 100 + '%';
        star.style.top = Math.random() * 100 + '%';
        
        const delay = Math.random() * 2;
        star.style.animationDelay = delay + 's';
        
        const brightness = Math.random() * 0.7 + 0.3;
        star.style.opacity = brightness;
        
        starsContainer.appendChild(star);
        totalStars++;
        createdCount++;
        
        updateCounters();
    }
    
    function createMeteor() {
        const meteor = document.createElement('div');
        meteor.className = 'meteor';
        
        meteor.style.left = Math.random() * 100 + '%';
        meteor.style.top = Math.random() * 30 + '%';
        
        document.body.appendChild(meteor);
        
        setTimeout(() => {
            meteor.remove();
        }, 1000);
    }
    
    function updateCounters() {
        starCount.textContent = totalStars;
        createdStars.textContent = createdCount;
    }
    
    function toggleMode() {
        document.body.classList.toggle('light-mode');
        
        if (document.body.classList.contains('light-mode')) {
            modeStatus.textContent = 'Денний';
            modeStatus.style.color = '#4a6fff';
        } else {
            modeStatus.textContent = 'Нічний';
            modeStatus.style.color = '#b388ff';
        }
    }
    
    function resetSky() {
        starsContainer.innerHTML = '';
        totalStars = 0;
        createdCount = 0;
        updateCounters();
        
        createInitialStars();
    }
    
    function createInitialStars() {
        for (let i = 0; i < 50; i++) {
            setTimeout(() => createStar(), i * 30);
        }
    }
    
    addStarBtn.addEventListener('click', function() {
        for (let i = 0; i < 5; i++) {
            setTimeout(() => createStar(), i * 100);
        }
    });
    
    addMeteorBtn.addEventListener('click', function() {
        for (let i = 0; i < 3; i++) {
            setTimeout(() => createMeteor(), i * 200);
        }
    });
    
    toggleModeBtn.addEventListener('click', toggleMode);
    resetBtn.addEventListener('click', resetSky);
    
    constellationItems.forEach(item => {
        item.addEventListener('click', function() {
            constellationItems.forEach(i => {
                i.style.backgroundColor = 'rgba(100, 120, 255, 0.2)';
                i.style.transform = 'scale(1)';
            });
            
            this.style.backgroundColor = 'rgba(138, 155, 255, 0.4)';
            this.style.transform = 'scale(1.1)';
            
            for (let i = 0; i < 10; i++) {
                setTimeout(() => createStar(), i * 50);
            }
        });
    });
    
    document.addEventListener('keydown', function(event) {
        if (event.code === 'Space') {
            event.preventDefault();
            createStar();
        }
    });
    
    window.addEventListener('click', function(event) {
        if (event.target === addStarBtn || event.target === addMeteorBtn || 
            event.target === toggleModeBtn || event.target === resetBtn) {
            return;
        }
        
        if (Math.random() > 0.7) {
            createStar();
        }
    });
    
    createInitialStars();
});